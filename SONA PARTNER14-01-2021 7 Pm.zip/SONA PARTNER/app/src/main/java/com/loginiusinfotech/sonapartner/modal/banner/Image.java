package com.loginiusinfotech.sonapartner.modal.banner;

public class Image {

    public String image;
    public String id;
    public Integer counter = null;

}
