package com.loginiusinfotech.sonapartner.activity;

import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.gson.Gson;
import com.loginiusinfotech.sonapartner.R;
import com.loginiusinfotech.sonapartner.modal.product.productAdd.ProductAdd;
import com.loginiusinfotech.sonapartner.modal.product.productAdd.ProductAddBody;
import com.loginiusinfotech.sonapartner.modal.product.productList.ProductListData;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryEdit.SubCategoryEdit;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryEdit.SubCategoryEditBody;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryView.SubCategoryView;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryView.SubCategoryViewBody;
import com.loginiusinfotech.sonapartner.remote.ApiClient;
import com.loginiusinfotech.sonapartner.remote.ApiInterface;
import com.squareup.picasso.Picasso;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddProductActivity extends AppCompatActivity {

    TextView title;
    Button btn_mul_category, btn_submit;
    ApiInterface mApiInterface;
    ProgressDialog pd;
    ArrayList<String> imagesEncodedList;
    Spinner spinner_offer;
    LinearLayout ll_offer;
    EditText et_product_name,et_description,et_offer_type,et_quantity;
    String str_offer,cat_id="",sub_cat_id;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        try {
            if (requestCode == 200 && resultCode == RESULT_OK && null != data) {
                imagesEncodedList = new ArrayList<String>();
                LinearLayout layout = (LinearLayout) findViewById(R.id.ll_dynamic_img);
                if (data.getClipData() != null) {
                    ClipData mClipData = data.getClipData();
                    for (int i = 0; i < mClipData.getItemCount(); i++) {
                        ClipData.Item item = mClipData.getItemAt(i);
                        Uri uri = item.getUri();
                        Bitmap bitmap = MediaStore.Images.Media.getBitmap(AddProductActivity.this.getContentResolver(), uri);
                        ImageView image = new ImageView(this);
                        image.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,800));
                        image.setScaleType(ImageView.ScaleType.FIT_XY);
                        image.setImageBitmap(bitmap);
                        image.setPadding(10,10,10,10);
                        layout.addView(image);
                        imagesEncodedList.add(imageToString(bitmap));
                    }
                } else if (data.getData() != null) {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(AddProductActivity.this.getContentResolver(), data.getData());
                    ImageView image = new ImageView(this);
                    image.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,800));
                    image.setScaleType(ImageView.ScaleType.FIT_XY);
                    image.setImageBitmap(bitmap);
                    image.setPadding(10,10,10,10);
                    layout.addView(image);
                    imagesEncodedList.add(imageToString(bitmap));
                }
            } else {
                Toast.makeText(this, "You haven't picked Image",
                        Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Something went wrong", Toast.LENGTH_LONG)
                    .show();
        }

        super.onActivityResult(requestCode, resultCode, data);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);
        title = findViewById(R.id.title);
        btn_submit = findViewById(R.id.btn_submit);
        spinner_offer = findViewById(R.id.spinner_offer);
        et_product_name = findViewById(R.id.et_product_name);
        et_offer_type = findViewById(R.id.et_offer_type);
        et_description = findViewById(R.id.et_description);
        et_quantity = findViewById(R.id.et_quantity);
        ll_offer = findViewById(R.id.ll_offer);
        btn_mul_category = findViewById(R.id.btn_mul_category);

        mApiInterface = ApiClient.getClient(ApiInterface.class);
        pd = new ProgressDialog(AddProductActivity.this);
        pd.setMessage("please wait ...");
        pd.setCancelable(false);
        title.setText("Add Product");

        btn_mul_category.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setType("image/*");
                intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                intent.setAction(Intent.ACTION_GET_CONTENT);
                startActivityForResult(Intent.createChooser(intent, "Select Picture"), 200);
            }
        });
        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (et_product_name.getText().toString().equals("")){
                    et_product_name.setError("Enter product name");
                    return;
                }

                if (imagesEncodedList == null){
                    Toast.makeText(AddProductActivity.this, "Select Image", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (btn_submit.getText().toString().equals("Save")){
                    subCategoryEdit(sub_cat_id,cat_id,
                            et_product_name.getText().toString());
                }else {
                    productAdd(cat_id, sub_cat_id, et_product_name.getText().toString(), et_description.getText().toString(),
                            str_offer, et_quantity.getText().toString(), et_offer_type.getText().toString(), imagesEncodedList);
                }
            }
        });
        try {
            if (!getIntent().getExtras().getString("product", "").equals("")){
                Gson gson = new Gson();
                ProductListData productListData = gson.fromJson(getIntent().getExtras().getString("product", ""), ProductListData.class);
//                cat_id=
//                sub_cat_id=
                et_description.setText(productListData.getDescription());
                imagesEncodedList=productListData.getImages();
                LinearLayout layout = (LinearLayout) findViewById(R.id.ll_dynamic_img);
                for (int i = 1; i < imagesEncodedList.size(); i++) {
                    ImageView image = new ImageView(AddProductActivity.this);
                    image.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,800));
                    image.setScaleType(ImageView.ScaleType.FIT_XY);
                    image.setPadding(10,10,10,10);
                    Picasso.get().load("" +productListData.getImages().get(i)).error(R.drawable.ic_launcher_foreground).into(image);
                    layout.addView(image);
                }
                title.setText("Edit Subcategory");
                btn_submit.setText("Save");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        spinner_offer.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                str_offer=adapterView.getItemAtPosition(i).toString().toLowerCase();
                if (str_offer.equals("yes")){
                    ll_offer.setVisibility(View.VISIBLE);
                }else {
                    ll_offer.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    public void drawerBack(View view) {
        finish();
    }

    private String imageToString(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] imgByte = byteArrayOutputStream.toByteArray();
        return Base64.encodeToString(imgByte, Base64.DEFAULT);
    }

    private void productAdd(String cat_id, String subcat_id, String productName, String description, String offer, String quantity, String offertype, ArrayList<String> images) {
        pd.show();
        Call<ProductAdd> request = mApiInterface.productAdd(new ProductAddBody(cat_id,subcat_id,productName,description,offer,quantity,offertype,images));
        request.enqueue(new Callback<ProductAdd>() {
            @Override
            public void onResponse(Call<ProductAdd> call, Response<ProductAdd> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200) {
                        Toast.makeText(AddProductActivity.this, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(AddProductActivity.this, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                pd.cancel();
            }

            @Override
            public void onFailure(Call<ProductAdd> call, Throwable t) {
                pd.cancel();
            }
        });
    }

    private void subCategoryEdit(String subcat_id, String cat_id, String subcategoryName) {
        pd.show();
        Call<SubCategoryEdit> request = mApiInterface.subCategoryEdit(new SubCategoryEditBody(subcat_id,cat_id,subcategoryName));
        request.enqueue(new Callback<SubCategoryEdit>() {
            @Override
            public void onResponse(Call<SubCategoryEdit> call, Response<SubCategoryEdit> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200) {
                        Toast.makeText(AddProductActivity.this, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        finish();
                    }else {
                        Toast.makeText(AddProductActivity.this, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                pd.cancel();
            }

            @Override
            public void onFailure(Call<SubCategoryEdit> call, Throwable t) {
                pd.cancel();
            }
        });
    }
}


