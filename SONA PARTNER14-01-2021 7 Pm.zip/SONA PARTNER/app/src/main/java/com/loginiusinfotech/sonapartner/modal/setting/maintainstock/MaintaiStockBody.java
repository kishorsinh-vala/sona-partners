package com.loginiusinfotech.sonapartner.modal.setting.maintainstock;

public class MaintaiStockBody {
    String product_id;
    String cat_id;
    String subcat_id;
    String quantity;

    public MaintaiStockBody(String product_id, String cat_id, String subcat_id, String quantity) {
        this.product_id = product_id;
        this.cat_id = cat_id;
        this.subcat_id = subcat_id;
        this.quantity = quantity;
    }
}
