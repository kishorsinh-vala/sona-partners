package com.loginiusinfotech.sonapartner.modal.product.productList;

public class ProductListBody {
    String cat_id;
    String subcat_id;

    public ProductListBody(String cat_id, String subcat_id) {
        this.cat_id = cat_id;
        this.subcat_id = subcat_id;
    }
}
