package com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryDelete;

public class SubCategoryDeleteBody {
    String subcat_id;

    public SubCategoryDeleteBody(String subcat_id) {
        this.subcat_id = subcat_id;
    }
}
