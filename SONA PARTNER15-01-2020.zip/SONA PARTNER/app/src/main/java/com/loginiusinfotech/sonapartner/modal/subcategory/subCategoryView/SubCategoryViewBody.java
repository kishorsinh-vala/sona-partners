package com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryView;

public class SubCategoryViewBody {
    String subcat_id;

    public SubCategoryViewBody(String subcat_id) {
        this.subcat_id = subcat_id;
    }
}
