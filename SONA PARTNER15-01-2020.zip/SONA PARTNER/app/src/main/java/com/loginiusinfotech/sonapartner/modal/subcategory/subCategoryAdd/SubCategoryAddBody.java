package com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryAdd;

public class SubCategoryAddBody {
    String cat_id;
    String subcategoryName;

    public SubCategoryAddBody(String cat_id, String subcategoryName) {
        this.cat_id = cat_id;
        this.subcategoryName = subcategoryName;
    }
}
