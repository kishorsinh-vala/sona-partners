package com.loginiusinfotech.sonapartner.modal.category.categoryUpdate;

public class CategoryUpdateBody {
    String id;
    String category;

    public CategoryUpdateBody(String id, String category) {
        this.id = id;
        this.category = category;
    }
}
