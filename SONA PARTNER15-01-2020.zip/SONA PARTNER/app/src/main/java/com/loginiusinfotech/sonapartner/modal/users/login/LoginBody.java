package com.loginiusinfotech.sonapartner.modal.users.login;

public class LoginBody {
    String email;
    String password;

    public LoginBody(String email, String password) {
        this.email = email;
        this.password = password;
    }
}