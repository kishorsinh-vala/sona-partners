package com.loginiusinfotech.sonapartner.modal.product.productDelete;

public class ProductDeleteBody {
    String product_id;

    public ProductDeleteBody(String product_id) {
        this.product_id = product_id;
    }
}
