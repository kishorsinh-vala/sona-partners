package com.loginiusinfotech.sonapartner.modal.product.productView;

public class ProductViewBody {
    String product_id;

    public ProductViewBody(String product_id) {
        this.product_id = product_id;
    }
}
