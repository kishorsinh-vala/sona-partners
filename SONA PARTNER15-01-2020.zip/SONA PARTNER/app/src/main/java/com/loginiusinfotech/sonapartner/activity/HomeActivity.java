package com.loginiusinfotech.sonapartner.activity;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.navigation.NavigationView;
import com.loginiusinfotech.sonapartner.R;
import com.loginiusinfotech.sonapartner.utils.AppConstants;
import com.loginiusinfotech.sonapartner.utils.Pref;

public class HomeActivity extends AppCompatActivity {

    private AppBarConfiguration mAppBarConfiguration;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        DrawerLayout drawer = findViewById(R.id.drawer_layout);
        NavigationView navigationView = findViewById(R.id.nav_view);
        mAppBarConfiguration = new AppBarConfiguration.Builder(
                R.id.nav_home, R.id.nav_manager)
                .setDrawerLayout(drawer)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        NavigationUI.setupWithNavController(navigationView, navController);
    }


    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment);
        return NavigationUI.navigateUp(navController, mAppBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public void drawerOpen(View view) {
        DrawerLayout navDrawer = findViewById(R.id.drawer_layout);
        if (!navDrawer.isDrawerOpen(Gravity.START)) {
            navDrawer.openDrawer(Gravity.START);
        } else {
            navDrawer.closeDrawer(Gravity.END);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        Pref.setPrefDate(HomeActivity.this, AppConstants.SAVE_USER_ID, "");
        Pref.setPrefDate(HomeActivity.this, AppConstants.SAVE_EMAIL, "");
        Pref.setPrefDate(HomeActivity.this, AppConstants.SAVE_ROLE_ID, "");
        Pref.setPrefDate(HomeActivity.this, AppConstants.SAVE_ROLE, "");
    }
}