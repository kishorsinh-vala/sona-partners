package com.loginiusinfotech.sonapartner.modal.category.categoryAdd;

public class CategoryAddBody {
    String category;

    public CategoryAddBody(String category) {
        this.category = category;
    }
}
