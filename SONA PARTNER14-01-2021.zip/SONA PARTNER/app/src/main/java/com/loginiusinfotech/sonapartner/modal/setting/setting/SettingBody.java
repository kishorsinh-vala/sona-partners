package com.loginiusinfotech.sonapartner.modal.setting.setting;

public class SettingBody {
    String key_of;
    String value;

    public SettingBody(String key_of, String value) {
        this.key_of = key_of;
        this.value = value;
    }
}
