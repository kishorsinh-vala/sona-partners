package com.loginiusinfotech.sonapartner.activity;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.telephony.PhoneNumberUtils;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Filter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.loginiusinfotech.sonapartner.R;
import com.loginiusinfotech.sonapartner.modal.category.categoryDelete.CategoryDelete;
import com.loginiusinfotech.sonapartner.modal.category.categoryDelete.CategoryDeleteBody;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryDelete.SubCategoryDelete;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryDelete.SubCategoryDeleteBody;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryList.SubCategoryList;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryList.SubCategoryListBody;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryList.SubCategoryListData;
import com.loginiusinfotech.sonapartner.remote.ApiClient;
import com.loginiusinfotech.sonapartner.remote.ApiInterface;
import com.loginiusinfotech.sonapartner.utils.AppConstants;
import com.loginiusinfotech.sonapartner.utils.Pref;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SubCategoryActivity extends AppCompatActivity {

    Recycle_Adpter recycle_adpter;
    RecyclerView recyclerView;
    ApiInterface mApiInterface;
    ProgressDialog pd;
    TextView title;
    SearchView searchView;
    FloatingActionButton fab_add;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sub_category);
        recyclerView = findViewById(R.id.recyclerView);
        fab_add = findViewById(R.id.fab_add);
        mApiInterface = ApiClient.getClient(ApiInterface.class);
        pd = new ProgressDialog(SubCategoryActivity.this);
        pd.setMessage("please wait ...");
        pd.setCancelable(false);
        title = findViewById(R.id.title);
        title.setText(getIntent().getExtras().getString("cat_name", ""));
        fab_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(SubCategoryActivity.this,AddSubCategoryActivity.class);
                intent.putExtra("cat_id",getIntent().getExtras().getString("cat_id", ""));
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        try {
            if (Pref.getPrefDate(SubCategoryActivity.this, AppConstants.SAVE_ROLE_ID,"").equals("2")){
                fab_add.setVisibility(View.VISIBLE);
            }else {
                fab_add.setVisibility(View.GONE);
            }
            pd.show();
            subCategoryList(getIntent().getExtras().getString("cat_id", ""));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void drawerBack(View view) {
        this.finish();
    }

    private void subCategoryList(String cat_id) {
        Call<SubCategoryList> request = mApiInterface.subCategoryList(new SubCategoryListBody(cat_id));
        request.enqueue(new Callback<SubCategoryList>() {
            @Override
            public void onResponse(Call<SubCategoryList> call, Response<SubCategoryList> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200)
                    {
                        recyclerView.setVisibility(View.VISIBLE);
                        recyclerView.setLayoutManager(new LinearLayoutManager(SubCategoryActivity.this, RecyclerView.VERTICAL, false));
                        recycle_adpter = new Recycle_Adpter(response.body().getData(), SubCategoryActivity.this);
                        recyclerView.setAdapter(recycle_adpter);
                        searchView = findViewById(R.id.searchView);

                        searchView.setQueryHint(Html.fromHtml("<font color = #5D5F96> Filter using Size</font>"));
                        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);

                        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
                        searchView.setMaxWidth(Integer.MAX_VALUE);

                        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                            @Override
                            public boolean onQueryTextSubmit(String query) {
                                recycle_adpter.getFilter().filter(query);
                                return false;
                            }

                            @Override
                            public boolean onQueryTextChange(String query) {
                                recycle_adpter.getFilter().filter(query);
                                return false;
                            }
                        });
                    } else {
                        recyclerView.setVisibility(View.GONE);
                        Toast.makeText(SubCategoryActivity.this, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                pd.cancel();
            }

            @Override
            public void onFailure(Call<SubCategoryList> call, Throwable t) {
                pd.cancel();
            }
        });
    }

    public class Recycle_Adpter extends RecyclerView.Adapter {

        List<SubCategoryListData> spacecrafts;
        List<SubCategoryListData> spacecraftsFilter;
        Context mContext;

        public Recycle_Adpter(List data, Context mContext) {
            this.spacecraftsFilter = data;
            this.spacecrafts = data;
            this.mContext = mContext;
        }

        @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@androidx.annotation.NonNull ViewGroup parent, int i) {

            View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_adapter_list_sub_category, parent, false);
            // set the view's size, margins, paddings and layout parameters
            Recycle_Adpter.MyViewHolder vh = new Recycle_Adpter.MyViewHolder(v); // pass the view to View Holder
            return vh;
        }

        @SuppressLint("SetTextI18n")
        @Override
        public void onBindViewHolder(@androidx.annotation.NonNull final RecyclerView.ViewHolder holder, final int position) {
            final Recycle_Adpter.MyViewHolder holder1 = (Recycle_Adpter.MyViewHolder) holder;
            final SubCategoryListData subCategoryListData = (SubCategoryListData) spacecraftsFilter.get(position);
            if (Pref.getPrefDate(mContext,AppConstants.SAVE_ROLE_ID,"").equals("2")){
                holder1.rl_edit_delete.setVisibility(View.VISIBLE);
            }else {
                holder1.rl_edit_delete.setVisibility(View.GONE);
            }
            holder1.tv_size.setText(subCategoryListData.getSubcategory_name());
            holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(mContext, SubCategoryViewActivity.class);
                    intent.putExtra("cat_id", "" + subCategoryListData.getId());
                    intent.putExtra("cat_name", "" + subCategoryListData.getSubcategory_name());
                    mContext.startActivity(intent);
                }
            });
            holder1.iv_telephone.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", "+91" + subCategoryListData.getMob_no(), null));
//                    startActivity(intent);
                }
            });
            holder1.iv_whatsapp.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
//                    openWhatsApp("" + subCategoryListData.getWhatsapp_no());
                }
            });
            holder1.cv_edit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent intent=new Intent(SubCategoryActivity.this,AddSubCategoryActivity.class);
                    intent.putExtra("cat_id",getIntent().getExtras().getString("cat_id", ""));
                    intent.putExtra("sub_cat_id",subCategoryListData.getId());
                    startActivity(intent);
                }
            });
            holder1.cv_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    new AlertDialog.Builder(mContext)
                            .setTitle("Delete Category?")
                            .setMessage("Are you sure you want to delete "+subCategoryListData.getSubcategory_name()+"?")
                            .setNegativeButton(android.R.string.no, null)
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface arg0, int arg1) {
                                    subCategoryDelete(subCategoryListData.getId());
                                }
                            }).create().show();
                }
            });
        }


        @Override
        public int getItemCount() {
            return spacecraftsFilter.size();
        }

        @Override
        public long getItemId(int position) {
            return getItemCount();
        }

        @Override
        public int getItemViewType(int position) {
            return position;
        }

        public class MyViewHolder extends RecyclerView.ViewHolder {
            ImageView image, iv_telephone, iv_whatsapp;
            TextView tv_discount, tv_size;
            RelativeLayout rl_tv_discount,rl_edit_delete;
            FloatingActionButton cv_edit,cv_delete;

            public MyViewHolder(@androidx.annotation.NonNull View itemView) {
                super(itemView);

                image = itemView.findViewById(R.id.image);
                iv_telephone = itemView.findViewById(R.id.iv_telephone);
                iv_whatsapp = itemView.findViewById(R.id.iv_whatsapp);
                tv_discount = itemView.findViewById(R.id.tv_discount);
                tv_size = itemView.findViewById(R.id.tv_size);
                rl_tv_discount = itemView.findViewById(R.id.rl_tv_discount);
                rl_edit_delete = itemView.findViewById(R.id.rl_edit_delete);
                cv_edit = itemView.findViewById(R.id.cv_edit);
                cv_delete = itemView.findViewById(R.id.cv_delete);
            }
        }
        public Filter getFilter() {
            return new Filter() {
                @RequiresApi(api = Build.VERSION_CODES.O)
                @Override
                protected FilterResults performFiltering(CharSequence charSequence) {
                    try {
                        if (charSequence.toString().isEmpty()) {
                            spacecraftsFilter = spacecrafts;
                        } else {
                            List<SubCategoryListData> filteredList = new ArrayList<>();
                            for (SubCategoryListData row : spacecrafts) {
                                if (row.getSubcategory_name().trim().toLowerCase().contains(charSequence.toString().trim().toLowerCase())) {
                                    filteredList.add(row);
                                }
                            }
                            spacecraftsFilter = filteredList;
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                    FilterResults filterResults = new FilterResults();
                    filterResults.values = spacecraftsFilter;
                    return filterResults;
                }

                @Override
                protected void publishResults(CharSequence charSequence, FilterResults filterResults) {
                    spacecraftsFilter = (ArrayList<SubCategoryListData>) filterResults.values;
                    notifyDataSetChanged();
                }
            };
        }
    }

    private void openWhatsApp(String number) {
        boolean isWhatsappInstalled = whatsappInstalledOrNot("com.whatsapp");
        if (isWhatsappInstalled) {

            Intent sendIntent = new Intent("android.intent.action.MAIN");
            sendIntent.setComponent(new ComponentName("com.whatsapp", "com.whatsapp.Conversation"));
            sendIntent.putExtra("jid", PhoneNumberUtils.stripSeparators("91" + number) + "@s.whatsapp.net");
            startActivity(sendIntent);
        } else {
            Uri uri = Uri.parse("market://details?id=com.whatsapp");
            Intent goToMarket = new Intent(Intent.ACTION_VIEW, uri);
            Toast.makeText(SubCategoryActivity.this, "WhatsApp not Installed", Toast.LENGTH_SHORT).show();
            startActivity(goToMarket);
        }
    }

    private boolean whatsappInstalledOrNot(String uri) {
        PackageManager pm = getPackageManager();
        boolean app_installed = false;
        try {
            pm.getPackageInfo(uri, PackageManager.GET_ACTIVITIES);
            app_installed = true;
        } catch (PackageManager.NameNotFoundException e) {
            app_installed = false;
        }
        return app_installed;
    }
    private void subCategoryDelete(String id) {
        Call<SubCategoryDelete> request = mApiInterface.subCategoryDelete(new SubCategoryDeleteBody(id));
        request.enqueue(new Callback<SubCategoryDelete>() {
            @Override
            public void onResponse(Call<SubCategoryDelete> call, Response<SubCategoryDelete> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200) {
                        Toast.makeText(SubCategoryActivity.this, "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        onResume();
                    }
                }
                pd.cancel();
            }

            @Override
            public void onFailure(Call<SubCategoryDelete> call, Throwable t) {
                pd.cancel();
            }
        });
    }
}