package com.loginiusinfotech.sonapartner.modal.product.productAdd;

import java.util.ArrayList;

public class ProductAddBody {

    String cat_id;
    String subcat_id;
    String productName;
    String description;
    String offer;
    String quantity;
    String offertype;
    ArrayList<String> images;

    public ProductAddBody(String cat_id, String subcat_id, String productName,
                          String description, String offer, String quantity, String offertype, ArrayList<String> images) {
        this.cat_id = cat_id;
        this.subcat_id = subcat_id;
        this.productName = productName;
        this.description = description;
        this.offer = offer;
        this.quantity = quantity;
        this.offertype = offertype;
        this.images = images;
    }
}
