package com.loginiusinfotech.sonapartner.modal.category.categoryDelete;

public class CategoryDeleteBody {
    String id;

    public CategoryDeleteBody(String id) {
        this.id = id;
    }
}
