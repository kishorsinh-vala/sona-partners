package com.loginiusinfotech.sonapartner.modal.banner;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class OfferBannerData {
    @SerializedName("subcategoryId")
    @Expose
    private String subcategoryId;

    @SerializedName("bannerImage")
    @Expose
    private String bannerImage;

    @SerializedName("offer")
    @Expose
    private String offer;

    @SerializedName("discount")
    @Expose
    private String discount;

    public String getSubcategoryId() {
        return subcategoryId;
    }

    public void setSubcategoryId(String subcategoryId) {
        this.subcategoryId = subcategoryId;
    }

    public String getBannerImage() {
        return bannerImage;
    }

    public void setBannerImage(String bannerImage) {
        this.bannerImage = bannerImage;
    }

    public String getOffer() {
        return offer;
    }

    public void setOffer(String offer) {
        this.offer = offer;
    }

    public String getDiscount() {
        return discount;
    }

    public void setDiscount(String discount) {
        this.discount = discount;
    }
}
