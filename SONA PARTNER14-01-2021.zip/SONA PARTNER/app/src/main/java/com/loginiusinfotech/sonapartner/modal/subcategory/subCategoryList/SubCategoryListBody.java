package com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryList;

public class SubCategoryListBody {
    String cat_id;

    public SubCategoryListBody(String cat_id) {
        this.cat_id = cat_id;
    }
}
