package com.loginiusinfotech.sonapartner.modal.product.productEdit;

public class ProductEditBody {
    String product_id;
    String cat_id;
    String subcat_id;
    String productName;
    String description;
    String offer;
    String quantity;
    String offertype;
    String image;

    public ProductEditBody(String product_id, String cat_id, String subcat_id, String productName, String description, String offer, String quantity, String offertype, String image) {
        this.product_id = product_id;
        this.cat_id = cat_id;
        this.subcat_id = subcat_id;
        this.productName = productName;
        this.description = description;
        this.offer = offer;
        this.quantity = quantity;
        this.offertype = offertype;
        this.image = image;
    }
}
