package com.loginiusinfotech.sonapartner.fragment;

import android.app.ProgressDialog;
import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;

import androidx.appcompat.widget.SearchView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.loginiusinfotech.sonapartner.R;
import com.loginiusinfotech.sonapartner.modal.category.categoryList.CategoryList;
import com.loginiusinfotech.sonapartner.modal.product.productList.ProductList;
import com.loginiusinfotech.sonapartner.modal.product.productList.ProductListBody;
import com.loginiusinfotech.sonapartner.modal.setting.maintainstock.MaintaiStock;
import com.loginiusinfotech.sonapartner.modal.setting.maintainstock.MaintaiStockBody;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryList.SubCategoryList;
import com.loginiusinfotech.sonapartner.modal.subcategory.subCategoryList.SubCategoryListBody;
import com.loginiusinfotech.sonapartner.remote.ApiClient;
import com.loginiusinfotech.sonapartner.remote.ApiInterface;
import com.loginiusinfotech.sonapartner.utils.AppConstants;
import com.loginiusinfotech.sonapartner.utils.Pref;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ManageStockFragment extends Fragment {

    View root;
    Spinner spinner_cat,spinner_sub_cat,spinner_product;
    ApiInterface mApiInterface;
    ProgressDialog pd;
    EditText et_quantity;
    Button btn_submit;
    String str_cat_id_spinner,str_sub_cat_id_spinner,str_product_spinner;
    public ManageStockFragment() {

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        root=inflater.inflate(R.layout.fragment_manage_stock, container, false);
        spinner_cat = root.findViewById(R.id.spinner_cat);
        spinner_sub_cat = root.findViewById(R.id.spinner_sub_cat);
        spinner_product = root.findViewById(R.id.spinner_product);
        et_quantity = root.findViewById(R.id.et_quantity);
        btn_submit = root.findViewById(R.id.btn_submit);

        mApiInterface = ApiClient.getClient(ApiInterface.class);
        pd = new ProgressDialog(getActivity());
        pd.setMessage("please wait ...");
        pd.setCancelable(false);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                maintainStock(et_quantity.getText().toString());
            }
        });
        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        try {
            categoryList();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void categoryList() {
        pd.show();
        Call<CategoryList> request = mApiInterface.categoryList();
        request.enqueue(new Callback<CategoryList>() {
            @Override
            public void onResponse(Call<CategoryList> call, Response<CategoryList> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200) {
                        ArrayList<String> categorArrayList = new ArrayList<>();
                        for (int i = 0; i < response.body().getData().size(); i++) {
                            categorArrayList.add(response.body().getData().get(i).getCategory());
                        }
                        ArrayAdapter adapter = new ArrayAdapter(getActivity(),
                                R.layout.item_spinner_list_category,
                                R.id.title, categorArrayList);
                        spinner_cat.setAdapter(adapter);
                        spinner_cat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                                str_cat_id_spinner = response.body().getData().get(position).getId();
                                subCategoryList(str_cat_id_spinner);
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {

                            }
                        });
                    } else {
                        Toast.makeText(getActivity(), "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                pd.dismiss();
            }

            @Override
            public void onFailure(Call<CategoryList> call, Throwable t) {
                pd.dismiss();
            }
        });
    }

    private void subCategoryList(String cat_id) {
        pd.show();
        Call<SubCategoryList> request = mApiInterface.subCategoryList(new SubCategoryListBody(cat_id));
        request.enqueue(new Callback<SubCategoryList>() {
            @Override
            public void onResponse(Call<SubCategoryList> call, Response<SubCategoryList> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200) {
                        ArrayList<String> categorArrayList = new ArrayList<>();
                        for (int i = 0; i < response.body().getData().size(); i++) {
                            categorArrayList.add(response.body().getData().get(i).getSubcategory_name());
                        }
                        ArrayAdapter adapter = new ArrayAdapter(getActivity(),
                                R.layout.item_spinner_list_category,
                                R.id.title, categorArrayList);
                        spinner_sub_cat.setAdapter(adapter);
                        spinner_sub_cat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                                str_sub_cat_id_spinner = response.body().getData().get(position).getId();
                                productList();
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {

                            }
                        });
                    } else {
                        Toast.makeText(getActivity(), "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                pd.dismiss();
            }

            @Override
            public void onFailure(Call<SubCategoryList> call, Throwable t) {
                pd.dismiss();
            }
        });
    }

    private void productList() {
        pd.show();
        Call<ProductList> request = mApiInterface.productList(new ProductListBody(str_cat_id_spinner,str_sub_cat_id_spinner));
        request.enqueue(new Callback<ProductList>() {
            @Override
            public void onResponse(Call<ProductList> call, Response<ProductList> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200) {
                        ArrayList<String> categorArrayList = new ArrayList<>();
                        for (int i = 0; i < response.body().getData().size(); i++) {
                            categorArrayList.add(response.body().getData().get(i).getProductName());
                        }
                        ArrayAdapter adapter = new ArrayAdapter(getActivity(),
                                R.layout.item_spinner_list_category,
                                R.id.title, categorArrayList);
                        spinner_sub_cat.setAdapter(adapter);
                        spinner_sub_cat.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                            @Override
                            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                                str_product_spinner = response.body().getData().get(position).getId();
                                et_quantity.setText(""+response.body().getData().get(position).getQuantity());
                            }

                            @Override
                            public void onNothingSelected(AdapterView<?> adapterView) {

                            }
                        });
                    } else {
                        Toast.makeText(getActivity(), "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                pd.dismiss();
            }

            @Override
            public void onFailure(Call<ProductList> call, Throwable t) {
                pd.dismiss();
            }
        });
    }

    private void maintainStock(String quantity) {
        pd.show();
        Call<MaintaiStock> request = mApiInterface.maintainStock(new MaintaiStockBody(str_product_spinner,str_cat_id_spinner,str_sub_cat_id_spinner,quantity));
        request.enqueue(new Callback<MaintaiStock>() {
            @Override
            public void onResponse(Call<MaintaiStock> call, Response<MaintaiStock> response) {
                if (response.body() != null) {
                    if (response.body().getResponsecode() == 200) {
                        Toast.makeText(getActivity(), "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        getActivity().onBackPressed();
                    } else {
                        Toast.makeText(getActivity(), "" + response.body().getMessage(), Toast.LENGTH_SHORT).show();
                    }
                }
                pd.dismiss();
            }

            @Override
            public void onFailure(Call<MaintaiStock> call, Throwable t) {
                pd.dismiss();
            }
        });
    }
}